import React from "react";
import ReactDOM from "react-dom/client";

const App = () => {
    let car = [];
    let number = [];
    let color = ['green', 'blue'];
    let name = [];

    let massage = (color.length > 0 ? <h1>Color is available</h1> : null)
    let getMassage = (a)=>{
        if(a){
            return <h1>Light On</h1>
        }else{
            return <h1>Light Off</h1>
        }
    }
    return(
        <>
        {car.length === 0 ? <h1>Empty car array</h1> : null}
        {number.length === 0 && <h1>Empty number array</h1>}

        {massage}
        {getMassage(1)}
        </>
    );
};

export default App;

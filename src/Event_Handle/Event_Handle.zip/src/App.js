import React from "react";
import ReactDOM from "react-dom/client";
import { MouseEvent } from "react";
const App = () => {
  let number = ['a', 'b'];
  const handler = (event: MouseEvent)=>console.log(event)
  return (
    <>
      <ul>
        {number.map((item, index)=>
        <li key={item} onClick={handler}>{item}</li>
        )}
      </ul>
    </>
  );
};

export default App;

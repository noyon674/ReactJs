import React from "react";
import ReactDOM from "react-dom/client";
import Card from "./Components/Card";

const App =()=>{
    return(
        <div>
            <Card name='Noyon' des='I am a Software Engineer'/>
            <Card name='Purna' des='I am a Food Engineer'/>
        </div>
    );
}

export default App;
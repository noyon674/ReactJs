import React from "react";
import ReactDOM from "react-dom/client";
import Card from "./Components/Card";
import Data from './Components/list.json';

const items = Data.map((item, index)=>{
    return(
        <div key={index}>
            <Card name={item.name} des={item.id}/>
        </div>
    )
});

const App =()=>{
    return(
        <div>
            {items};
        </div>
    );
}

export default App;
import React from "react";
import ReactDOM from "react-dom/client";

const Card = (props)=>{
    const {name, des} = props;
    return(
        <div className="card">
            <h1>{name}</h1> {/* props */}
            <p>{des}</p> {/*props with destructuring */}
        </div>
    );
};

export default Card;
import React from "react";
import ReactDOM from "react-dom/client";
import Card from "./Components/Card";

const App =()=>{
    return(
        <div>
            <Card />
            <Card />
        </div>
    );
}

export default App;
import React from "react";
import ReactDOM from "react-dom/client";

const Card = ()=>{
    return(
        <div className="card">
            <h1>Noyon</h1>
            <p>Hi, I am an Engineer.</p>
        </div>
    );
};

export default Card;
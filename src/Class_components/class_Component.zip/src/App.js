import React from "react";
import ReactDOM from "react-dom/client";
import Card from "./Components/Card";

const App = () => {
    return <Card name = 'Noyon' age = '23'/>
};

export default App;

import React, {Component} from "react";
import ReactDOM from "react-dom/client";

class Card extends Component{
    render(){
        return(
            <div className="card">
                <h1>{this.props.name}</h1>
                <p>{this.props.age}</p>
            </div>
        );
    }
}

export default Card;
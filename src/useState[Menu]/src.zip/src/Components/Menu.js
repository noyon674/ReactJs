import React, { useState } from "react";

const Menu = ()=>{
    const menu = ['Home', 'About', 'Product', 'Contact'];
    const [selectedIndex, setSelectedIndex] = useState(-1);
    return(
        <div className="card">
            <ul className="ul">
                {menu.map((item, index)=><li className={selectedIndex === index ? 'listItem active': 'listItem'} onClick={()=>{setSelectedIndex(index)}}>
                    {item}
                    </li>)}
            </ul>
        </div>
    );
};

export default Menu;
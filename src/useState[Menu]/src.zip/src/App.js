import React from "react";
import ReactDOM from "react-dom/client";
import Menu from "./Components/Menu";

const App = () => {
  return(
    <Menu />
  );
};

export default App;
